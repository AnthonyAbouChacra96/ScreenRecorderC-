﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using FfmpegApp.Models;
//using MediaToolkit;
//using MediaToolkit.Model;

namespace ScreenRecorder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           // string appPath = $"{Path.GetDirectoryName(Application.ExecutablePath)}\\{nametemp}";
            Rectangle bounds = Screen.FromControl(this).Bounds;
            screenRec = new ScreenRecorder(bounds, outputPath);
            tmrRecord.Start();
            tmrDel.Start();
            // screenRec.SetEnvPathForFfmpeg();
            //  MessageBox.Show(appPath);
        }
        
        private string OutputType { get; set; }
        public string extension { get; set; }
        private Button lastClickedButton = null;
        // Filing variables:
        string outputPath = "";
        bool pathSelected = false;
        string finalVidName = "FinalVideo.mp4";

        // Screen recorder object:
        ScreenRecorder screenRec = new ScreenRecorder(new Rectangle(), "");
        private async void convertButton_Click(object sender, EventArgs e)
        {
            //if (string.IsNullOrEmpty(OutputType))
            //{
            //    MessageBox.Show("Please select output format");
            //}
            //else
            //{
                
            //    var inputFilePath = txtInputFile.Text;
            //    var fileName = Path.GetFileNameWithoutExtension(inputFilePath);
            //    string outputFilePath = txtOutputFolder.Text + $"\\{fileName}-{DateTime.Now.Ticks}." + OutputType;

            //    var conversionFileDetails = new ConvertFileDetails
            //    {
            //        InputFilePath = inputFilePath,
            //        OutputFilePath = outputFilePath
            //    };

            //    Task<string> conversionTask = new Task<string>(() => FfmpegHandler.ConvertFile(conversionFileDetails, ConvertProgressEvent,ConversionCompleteEvent));
            //    conversionTask.Start();
            //    DisableActionButtons();


            //    MessageBox.Show("Conversion in progress please wait...");
            //    var result = await conversionTask;
            //    MessageBox.Show("File conversion completed.");
            //    EnableActionButtons();

            //    //LaunchCommandLineApp(txtInputFile.Text, output);

            //}
            
        }

        //private void ConvertProgressEvent(object sender, MediaToolkit.ConvertProgressEventArgs e)
        //{
        //    pbFileConversion.Invoke(new Action(() =>
        //    {
        //        pbFileConversion.Value = (int)(e.ProcessedDuration.TotalMilliseconds / e.TotalDuration.TotalMilliseconds * 100);
        //    }));

        //}

        //private void ConversionCompleteEvent(object sender, ConversionCompleteEventArgs e)
        //{
        //    pbFileConversion.Invoke(new Action(() =>
        //    {
        //        pbFileConversion.Value = 0;
        //    }));
        //}


        private void DisableActionButtons()
        {
            convertButton.Enabled = folderOpenButton.Enabled = false;
        }

        private void EnableActionButtons()
        {
            convertButton.Enabled = folderOpenButton.Enabled  = true;
        }

        //private void LaunchCommandLineApp(string input, string outputFile)
        //{
        //    FfmpegHandler.ExecuteFFMpeg($"-i \"{input}\" \"{outputFile}\"");
        //}
        private bool canRecord()
        {
            if (string.IsNullOrWhiteSpace(txtVideoName.Text))
            {
                MessageBox.Show("Please insert a name for the recording .", "Missing");
                return false;
            }
            if (!pathSelected)
            {
                MessageBox.Show("Please select an output path first", "Missing");
                return false;
            }
            return true;
        }
        private void folderOpenButton_Click(object sender, EventArgs e)
        {
            //Create output path:
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            folderBrowser.Description = "Select an Output Folder";

            if (folderBrowser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                outputPath = @folderBrowser.SelectedPath;
                pathSelected = true;
                screenRec.outPath = outputPath;
                txtOutputFolder.Text = folderBrowser.SelectedPath;
            }
            else
            {
                MessageBox.Show("Please select an output folder.", "Error");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void SetOutputType(string outputType, Button btnSelectedType)
        {
            this.OutputType = outputType;

            btnSelectedType.BackColor = Color.Crimson;

            // Revert the background color of the previously-colored button, if any
            if (lastClickedButton != null)
                lastClickedButton.BackColor = Color.DimGray;

            // Update the previously-colored button
            lastClickedButton = btnSelectedType;
        }

        private void btnToAvi_Click(object sender, EventArgs e)
        {
            SetOutputType("avi", (Button)sender);            
        }

        private void btnToMp4_Click(object sender, EventArgs e)
        {
            SetOutputType("mp4", (Button)sender);
        }

        private void btnToMPEG_Click(object sender, EventArgs e)
        {
            SetOutputType("mpeg", (Button)sender);
        }

        private void btnToWmv_Click(object sender, EventArgs e)
        {
            SetOutputType("wmv", (Button)sender);
        }

        private void btnToFlv_Click(object sender, EventArgs e)
        {
            SetOutputType("flv", (Button)sender);
        }

        private void btnToMp3_Click(object sender, EventArgs e)
        {
            SetOutputType("mp3", (Button)sender);
        }

        private void vcTimer_Tick(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!canRecord()) return;
            pbRec.Show();
            screenRec.start();
            this.extension = "mp4";
            screenRec.setVideoName($"{txtVideoName.Text.Trim()}.{extension}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pbRec.Hide();
        }

        private void tmrRecord_Tick(object sender, EventArgs e)
        {
            screenRec.RecordVideo();
            screenRec.RecordAudio();
            lblTimer.Text = screenRec.getElapsed();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tmrRecord.Stop();
            screenRec.Stop();
            pbRec.Hide();
            Application.Restart();
        }

        private void tmrDel_Tick(object sender, EventArgs e)
        {
         //  if(!screenRec.hasStarted) screenRec.DeleteOlder(30);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            screenRec.cleanUp();
        }
    }
}
