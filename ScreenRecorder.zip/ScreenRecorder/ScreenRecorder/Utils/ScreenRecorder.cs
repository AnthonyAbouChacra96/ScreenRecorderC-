﻿using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Runtime.InteropServices;

using Accord.Video.FFMPEG;
using System.Windows.Forms;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ScreenRecorder
{
    class ScreenRecorder
    {
        //Video variables:
        private Rectangle bounds;
        // public string outputPath = "";
        private string outputPath;

        public string outPath
        {
            get { return outputPath; }
            set { outputPath = value; }
        }

        private string tempPath = "";
        private int fileCount = 1;
        private List<string> inputImageSequence = new List<string>();

        //File variables:
        private string audioName = "mic-temp.wav";
        private string videoName = "video-temp.mp4";
        private string finalName = "FinalVideo.mp4";
        public bool hasStarted = false;
        //Time variable:
        Stopwatch watch = new Stopwatch();
        Stopwatch Vidwatch = new Stopwatch();

        //Audio variables:
        public static class NativeMethods
        {
            [DllImport("winmm.dll", EntryPoint = "mciSendStringA", ExactSpelling = true, CharSet = CharSet.Ansi, SetLastError = true)]
            public static extern int record(string lpstrCommand, string lpstrReturnString, int uReturnLength, int hwndCallback);
        }
        //public void SetEnvPathForFfmpeg()
        //{
        //    string startupPath = Environment.CurrentDirectory;
        //    var name = "PATH";
        //    var scope = EnvironmentVariableTarget.Machine;
        //    var oldValue = Environment.GetEnvironmentVariable(name, scope);

        //    if (!oldValue.Contains(startupPath))
        //    {
        //        var newValue = oldValue + $@";{startupPath}";
        //        Environment.SetEnvironmentVariable(name, newValue, scope);
        //    }
        //}
        //ScreenRecorder Object:

        public ScreenRecorder(Rectangle b, string outPath)
        {
            //Create temporary folder for screenshots:
            CreateTempFolder("tempScreenCaps");
            Vidwatch.Start();
            //Set variables:
            bounds = b;
            outputPath = outPath;
        }

        //Create temporary folder:
        private void CreateTempFolder(string name)
        {
            string pathName = $"{Path.GetDirectoryName(Application.ExecutablePath)}\\{name}";
            Directory.CreateDirectory(pathName);
            tempPath = pathName;
        }

        //Change final video name:
        public void setVideoName(string name)
        {
            finalName = name;
        }

        //Delete all files and directory:
        private void DeletePath(string targetDir)
        {
            string[] files = Directory.GetFiles(targetDir);
            string[] dirs = Directory.GetDirectories(targetDir);

            //Delete each file:
            foreach (string file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }

            //Delete the path:
            foreach (string dir in dirs)
            {
                DeletePath(dir);
            }

            Directory.Delete(targetDir, false);
        }

        //Delete all files except the one specified:
        private void DeleteFilesExcept(string targetDir, string excDir)
        {
            string[] files = Directory.GetFiles(targetDir);

            //Delete each file except specified:
            foreach (string file in files)
            {
                if (file != excDir)
                {
                    File.SetAttributes(file, FileAttributes.Normal);
                    File.Delete(file);
                }
            }
        }
        //Deletes Video and audio temp files:
        private void DeleteFiles(string targetDir, string video, string audio)
        {
            string[] files = Directory.GetFiles(targetDir);
            foreach (string file in files)
            {
                if (file == video || file == audio)
                {
                    File.SetAttributes(file, FileAttributes.Normal);
                    File.Delete(file);
                }
            }
        }
        //Delete all the screen recordings that exceeded (nb) seconds:
        public async Task DeleteOlder(double nb)
        {
            DateTime time = DateTime.Now.AddSeconds(-nb);
            Directory.GetFiles(tempPath)
           .Select(f => new FileInfo(f))
           .Where(f => f.CreationTime < time)
           .ToList()
           .ForEach(f => { f.Delete(); inputImageSequence.Remove(f.FullName); Console.WriteLine($"delete{f.FullName}"); });

        }

        //Clean up program on close:
        public void cleanUp()
        {
            if (Directory.Exists(tempPath))
            {
                DeletePath(tempPath);
            }
        }

        //Return elapsed time:
        public string getElapsed()
        {

            return string.Format("{0:D2}:{1:D2}:{2:D2}", watch.Elapsed.Hours, watch.Elapsed.Minutes, watch.Elapsed.Seconds);
        }
        public void start()
        {
            if (hasStarted) return;
            //Keep track of time:
            watch.Start();
            Vidwatch.Stop();
            hasStarted = true;
        }
        //Record video:
        public void RecordVideo()
        {
            // return;
            using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    //Add screen to bitmap:
                    g.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
                }
                //Save screenshot:
                string name = tempPath + @"\screenshot-" + fileCount + ".png";
                bitmap.Save(name, ImageFormat.Png);
                inputImageSequence.Add(name);
                fileCount++;
            }
        }

        //Record audio:
        public void RecordAudio()
        {
            NativeMethods.record("open new Type waveaudio Alias recsound", "", 0, 0);
            NativeMethods.record("record recsound", "", 0, 0);
        }

        //Save audio file:
        private void SaveAudio()
        {
            //Replace path to fit the correct format:
            string ss = (outputPath + "\\" + audioName).Replace(@"\", @"/");
            string audioPath = "save recsound " + ss;
            Console.WriteLine("\n\n" + audioPath + "\n\n");
            NativeMethods.record(audioPath, "", 0, 0);
            NativeMethods.record("close recsound", "", 0, 0);
        }

        //Save video file:
        private void SaveVideo(int width, int height, int frameRate)
        {
            using (VideoFileWriter vFWriter = new VideoFileWriter())
            {
                //Create new video file:
                vFWriter.Open(outputPath + @"\" + videoName, width, height, frameRate, VideoCodec.MPEG4);

                //Make each screenshot into a video frame:
                foreach (string imageLocation in inputImageSequence)
                {
                    Bitmap imageFrame = System.Drawing.Image.FromFile(imageLocation) as Bitmap;
                    vFWriter.WriteVideoFrame(imageFrame);
                    imageFrame.Dispose();
                }

                //Close:
                vFWriter.Close();
            }
        }

        //Combine video and audio files:
        private async Task CombineVideoAndAudio(string video, string audio, string tmp)
        {
            string args = $"/k ffmpeg.exe -i \"{outputPath}\\{video}\" -i \"{outputPath}\\{audio}\"  {outputPath}\\{tmp + finalName.Replace(" ", "-")}& exit /b";
            Console.WriteLine("\n\n" + args);
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                FileName = "cmd.exe",
                //   WorkingDirectory = ten,
                Arguments = args
            };
            //  Process.Start(startInfo);
            using (Process exeProcess = Process.Start(startInfo))
            {
                exeProcess.WaitForExit();
            }
        }
        // Cutting video n seconds less than the start :
        private async Task CutVideo(string video, string output, int start, int end, int n)
        {
            string command = $"/k ffmpeg.exe -i \"{video}\" -ss {start - n} -t {end} \"{output}\" & exit /b";
            Console.WriteLine(command);
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                CreateNoWindow = false,
                UseShellExecute = true,
                FileName = "cmd.exe",
                //   WorkingDirectory = ten,
                Arguments = command
            };
            //  Process.Start(startInfo);
            using (Process exeProcess = Process.Start(startInfo))
            {
                exeProcess.WaitForExit();
            }
        }
        public async void Stop()
        {
            //MessageBox.Show("till start=>"+Convert.ToInt32( Vidwatch.Elapsed.TotalSeconds)+"\n till stop =>"+Convert.ToInt32( watch.Elapsed.TotalSeconds));
            if (!hasStarted) return;
            //Stop watch:
            watch.Stop();
            int start = Convert.ToInt32(Vidwatch.Elapsed.TotalSeconds);
            int end = Convert.ToInt32(watch.Elapsed.TotalSeconds);
            int less = 30;
            //Video variables:
            int width = bounds.Width;
            int height = bounds.Height;
            int frameRate = 10;
            string tmp = (start > less) ? "temp-" : "";
            //Save audio:
            SaveAudio();
            //Save video:
            SaveVideo(width, height, frameRate);
            //Combine audio and video files:
            await CombineVideoAndAudio(videoName, audioName, tmp);
            //if the start timing  exceeded (less) seconds cut from start-less :
            if (start > less)
            {
                await CutVideo($@"{outputPath}\{tmp + finalName.Replace(" ", " - ")}", $@"{outputPath}\{finalName.Replace(" ", " - ")}", start, end + less, less);
                File.Delete($@"{outputPath}\{tmp + finalName.Replace(" ", " - ")}");
            }
            //Delete the screenshots:
            DeletePath(tempPath);
            ////Delete separated video and audio files:
            //DeleteFilesExcept(outputPath, outputPath + "\\" + finalName.Replace(" ","-"));//replacing spaces for slug 

            //Delete video and audio temperory files
            DeleteFiles(outputPath, outputPath + @"\" + videoName, outputPath + @"\" + audioName);
            hasStarted = false;
            //Show the recorded video :
            Process.Start("explorer.exe", $@"/select,{outputPath}\{finalName.Replace(" ", "-")}");
        }
    }
}